module fr.ensma.a3.ia {
    requires javafx.controls;
    exports fr.ensma.a3.ia;
}
