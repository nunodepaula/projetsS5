/**
 * 
 */
package fr.ensma.a3.ia.Case;

/**
 * @author alvaresn
 *
 */
public class CaseModele {

	/**
	 * 
	 */
	public CaseModele() {
		// TODO Auto-generated constructor stub
	}

}
