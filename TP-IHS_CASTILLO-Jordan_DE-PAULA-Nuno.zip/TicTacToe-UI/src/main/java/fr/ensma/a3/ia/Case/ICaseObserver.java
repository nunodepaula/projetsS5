/**
 * 
 */
package fr.ensma.a3.ia.Case;

/**
 * @author alvaresn
 *
 */
public interface ICaseObserver {

	public void actionEvent();
}
