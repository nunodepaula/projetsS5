/**
 * 
 */
package fr.ensma.a3.ia.Plateau;

/**
 * @author alvaresn
 *
 */
public class PlateauModele {

	/**
	 * 
	 */
	public PlateauModele() {
		// TODO Auto-generated constructor stub
	}

}
