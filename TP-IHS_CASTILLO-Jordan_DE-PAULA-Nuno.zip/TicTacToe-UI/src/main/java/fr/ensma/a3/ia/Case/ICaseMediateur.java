package fr.ensma.a3.ia.Case;

public interface ICaseMediateur {
	
	public void action(String etat);
}
