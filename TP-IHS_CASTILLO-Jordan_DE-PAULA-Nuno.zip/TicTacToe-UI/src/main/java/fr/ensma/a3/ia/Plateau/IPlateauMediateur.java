/**
 * 
 */
package fr.ensma.a3.ia.Plateau;

import javafx.scene.Node;

/**
 * @author alvaresn
 *
 */
public interface IPlateauMediateur {

	public void ajouterComposant(Node e, int column, int row);
}
