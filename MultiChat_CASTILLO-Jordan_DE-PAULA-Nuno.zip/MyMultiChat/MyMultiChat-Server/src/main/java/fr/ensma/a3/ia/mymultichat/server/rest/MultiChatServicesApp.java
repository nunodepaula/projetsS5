package fr.ensma.a3.ia.mymultichat.server.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/services")
public class MultiChatServicesApp extends Application{
	
}
